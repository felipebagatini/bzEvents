package com.example.bzevents;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.bzevents.ArquivoBanco.Banco;
import com.example.bzevents.Objetos.DadosRegistroEvento;

import java.util.ArrayList;

public class TelaLoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screenlogin);

        Button btn = findViewById(R.id.btnLogin);
        Button btnReg = findViewById(R.id.btnReg);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoginMethod();
            }
        });

        btnReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RegisterMethod();
            }
        });
    }

    private void LoginMethod(){

        EditText userTxt = findViewById(R.id.userEditText);
        EditText passTxt = findViewById(R.id.passwordEditText);

        String userText = userTxt.getText().toString().trim();
        String passwordText = passTxt.getText().toString().trim();

        if(userText.equals("Felipe") && passwordText.equals("felipe08"))
        {
            startActivity(new Intent(TelaLoginActivity.this, TelaMainActivity.class));
        }
        else
        {
            Toast errorMsg = Toast.makeText(getApplicationContext(),
                    "Usuário ou senha incorretos.", Toast.LENGTH_SHORT);

            errorMsg.show();
        }
    }

    private void RegisterMethod()
    {
        startActivity(new Intent(TelaLoginActivity.this, TelaRegisterActivity.class));
    }
}
