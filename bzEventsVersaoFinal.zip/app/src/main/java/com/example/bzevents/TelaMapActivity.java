package com.example.bzevents;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class TelaMapActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screenmap);

        ImageButton closeBtn = findViewById(R.id.closeMapBtn);
        Button cadMapBtn = findViewById(R.id.cadMapBtn);

        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(TelaMapActivity.this, TelaEventoRegActivity.class));
            }
        });

        cadMapBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(TelaMapActivity.this, TelaEventoRegActivity.class));
            }
        });
    }
}
