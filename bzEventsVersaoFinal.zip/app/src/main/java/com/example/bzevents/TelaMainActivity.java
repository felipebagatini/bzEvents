package com.example.bzevents;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.bzevents.ArquivoBanco.Banco;
import com.example.bzevents.Objetos.DadosRegistroEvento;

import java.util.ArrayList;

public class TelaMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screemain);

        ImageButton chatBtn = findViewById(R.id.chatBtn);
        ImageButton eventBtn = findViewById(R.id.addEventBtn);
        ImageButton closeBtn = findViewById(R.id.quitBtnMain);

        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(TelaMainActivity.this, TelaLoginActivity.class));
            }
        });

        chatBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openChat();
            }
        });

        eventBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerEvent();
            }
        });

        Banco db = new Banco(this);
        ArrayList<DadosRegistroEvento> data = db.getItem();

        ArrayList<String> dadosEventoList = new ArrayList<>();
        ListView lstView = findViewById(R.id.listView);
        for(int i = 0; i < data.size(); i++)
        {
            DadosRegistroEvento dados = new DadosRegistroEvento();
            String label = dados.makeLabelToList(data.get(i).getNomeEvento());

            dadosEventoList.add(label);
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_expandable_list_item_1, dadosEventoList);

        lstView.setAdapter(adapter);

        TextView labelNmb = findViewById(R.id.textView7);
        labelNmb.setText(dadosEventoList.size() + " eventos confirmados esta semana");

    }
    private void openChat()
    {
        startActivity(new Intent(TelaMainActivity.this, TeleChatActivity.class));
    }

    private void registerEvent()
    {
        startActivity(new Intent(TelaMainActivity.this, TelaEventoRegActivity.class));
    }
}
