package com.example.bzevents.ArquivoBanco;

import static android.content.Context.MODE_PRIVATE;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import com.example.bzevents.Objetos.DadosRegistroEvento;

import java.util.ArrayList;

public class Banco extends SQLiteOpenHelper
{
    private static final String DATABASE_NAME = "EVENTOS";

    private static final int DATABASE_VERSION = 1;
    public Banco(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase)
    {
        final String SQL_CREATE_WAITLIST_TABLE = "CREATE TABLE EVENTOS (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "NOME TEXT," +
                "LOCAL TEXT," +
                "HORARIO FLOAT," +
                "DIA TEXT" +
                ");";

        sqLiteDatabase.execSQL(SQL_CREATE_WAITLIST_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS ITEM" );
        onCreate(sqLiteDatabase);
    }

    public void InsereDados(DadosRegistroEvento dados)
    {
        SQLiteDatabase dataDb = this.getWritableDatabase();
        ContentValues dadosEv = new ContentValues();
        dadosEv.put("NOME", dados.getNomeEvento());
        dadosEv.put("LOCAL", dados.getNomeLocal());
        dadosEv.put("HORARIO", dados.getHorario());
        dadosEv.put("DIA", dados.getHorario());

        dataDb.insert("EVENTOS", null, dadosEv);
    }

    @SuppressLint("Range")
    public ArrayList<DadosRegistroEvento> getItem()
    {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM EVENTOS", null);
        if (cursor != null)
            cursor.moveToFirst();

        ArrayList<DadosRegistroEvento> listEvents = new ArrayList<>();

        while(cursor.moveToNext())
        {
            DadosRegistroEvento dadosEvento = new DadosRegistroEvento();
            dadosEvento.setNomeEvento(cursor.getString(1));
            dadosEvento.setNomeLocal(cursor.getString(2));
            dadosEvento.setHorario(cursor.getString(3));
            dadosEvento.setDia(cursor.getString(4));

            listEvents.add(dadosEvento);
        }

        cursor.close();

        return listEvents;
    }
}
