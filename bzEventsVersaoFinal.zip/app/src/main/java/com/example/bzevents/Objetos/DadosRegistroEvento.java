package com.example.bzevents.Objetos;

public class DadosRegistroEvento
{
    private String Nome;
    private String Local;
    private String Hora;
    private String Dia;

    public String makeLabelToList(String nome)
    {
        String lbl = "Evento: " + nome;

        return lbl;
    }
    public String getNomeEvento(){
        return Nome;
    }

    public void setNomeEvento(String nome){
        this.Nome = nome;
    }

    public String getNomeLocal(){
        return Local;
    }

    public void setNomeLocal(String local){
        this.Local = local;
    }

    public String getHorario(){
        return Hora;
    }

    public void setHorario(String horario){
        this.Hora = horario;
    }

    public String getDia(){
        return Dia;
    }

    public void setDia(String dia){
        this.Dia = dia;
    }
}
