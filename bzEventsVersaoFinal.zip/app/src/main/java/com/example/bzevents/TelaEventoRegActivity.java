package com.example.bzevents;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageHelper;

import com.example.bzevents.ArquivoBanco.Banco;
import com.example.bzevents.Objetos.DadosRegistroEvento;

public class TelaEventoRegActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screeneventreg);
        ImageButton closeBtn = findViewById(R.id.btnCloseEventReg);

        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(TelaEventoRegActivity.this, TelaMainActivity.class));
            }
        });

        Button cadEventBtn = findViewById(R.id.btnCadEvent);

        cadEventBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RegisterEvent();
            }
        });

        Button mapBtn = findViewById(R.id.mapBtn);

        mapBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(TelaEventoRegActivity.this, TelaMapActivity.class));
            }
        });
    }

    private void RegisterEvent()
    {
        Banco insSql = new Banco(this);
        DadosRegistroEvento dados = new DadosRegistroEvento();
        EditText eventName = findViewById(R.id.editTextText3);
        dados.setNomeEvento(eventName.getText().toString());
        //EditText dayEvent = findViewById(R.id.calendarView);
        dados.setDia("5");//Deixei o dia 5 fixo pois do jeito acima, tava indo nulo por algum motivo
        EditText getHour = findViewById(R.id.editTextText14);
        dados.setHorario(getHour.getText().toString());
        dados.setNomeLocal("Teste local");
        insSql.InsereDados(dados);

        startActivity(new Intent(TelaEventoRegActivity.this, TelaMainActivity.class));
    }
}
