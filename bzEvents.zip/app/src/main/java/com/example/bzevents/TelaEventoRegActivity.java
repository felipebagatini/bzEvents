package com.example.bzevents;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class TelaEventoRegActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screeneventreg);
        ImageButton closeBtn = findViewById(R.id.btnCloseEventReg);

        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(TelaEventoRegActivity.this, TelaMainActivity.class));
            }
        });

        Button cadEventBtn = findViewById(R.id.btnCadEvent);

        cadEventBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(TelaEventoRegActivity.this, TelaMainActivity.class));
            }
        });

        Button mapBtn = findViewById(R.id.mapBtn);

        mapBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(TelaEventoRegActivity.this, TelaMapActivity.class));
            }
        });
    }
}
