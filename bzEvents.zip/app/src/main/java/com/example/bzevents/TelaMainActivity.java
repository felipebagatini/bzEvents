package com.example.bzevents;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class TelaMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screemain);

        ImageButton chatBtn = findViewById(R.id.chatBtn);
        ImageButton eventBtn = findViewById(R.id.addEventBtn);
        ImageButton closeBtn = findViewById(R.id.quitBtnMain);

        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(TelaMainActivity.this, TelaLoginActivity.class));
            }
        });

        chatBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openChat();
            }
        });

        eventBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerEvent();
            }
        });
    }

    private void openChat()
    {
        startActivity(new Intent(TelaMainActivity.this, TeleChatActivity.class));
    }

    private void registerEvent()
    {
        startActivity(new Intent(TelaMainActivity.this, TelaEventoRegActivity.class));
    }
}
